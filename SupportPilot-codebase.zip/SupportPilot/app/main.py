"""FastAPI entry point for SupportPilot."""
from __future__ import annotations
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from uuid import uuid4
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .supportpilot.schemas import TicketRequest, IntegrationTicketRequest, EmailTicketRequest
from .supportpilot.pipeline import TicketPipeline
from .supportpilot.db import init_db, save_ticket, get_analytics

pipeline = TicketPipeline()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="SupportPilot API",
    description="Local-first multilingual support-ticket classification and response drafting.",
    version="0.1.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501", "http://127.0.0.1:8501"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"name": "SupportPilot API", "version": "0.1.0", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "services": pipeline.health()}

@app.post("/tickets/predict")
def predict_ticket(ticket: TicketRequest):
    ticket_id = str(uuid4())
    result = pipeline.predict(ticket.subject, ticket.body)
    predictions = result["predictions"]
    record = {
        "ticket_id": ticket_id, "created_at": datetime.now(timezone.utc).isoformat(),
        "subject": ticket.subject, "body": ticket.body, "language": ticket.language,
        "queue": predictions["queue"].get("label"), "priority": predictions["priority"].get("label"),
        "type": predictions["type"].get("label"), "tags": result["tags"],
        "status": "classified" if any(v.get("available") for v in predictions.values()) else "models_not_trained",
        "escalated": result["escalated"], "model_status": str(result["model_health"]),
    }
    save_ticket(record)
    return {"ticket_id": ticket_id, **result}

@app.post("/tickets/resolve")
def resolve_ticket(ticket: TicketRequest):
    ticket_id = str(uuid4())
    result = pipeline.resolve(ticket.subject, ticket.body, ticket.language)
    predictions = result["predictions"]
    record = {
        "ticket_id": ticket_id, "created_at": datetime.now(timezone.utc).isoformat(),
        "subject": ticket.subject, "body": ticket.body, "language": ticket.language,
        "queue": predictions["queue"].get("label"), "priority": predictions["priority"].get("label"),
        "type": predictions["type"].get("label"), "tags": result["tags"],
        "status": result["status"], "escalated": result["escalated"],
        "response_draft": result["response_draft"], "sources": result["sources"],
        "model_status": str(result["model_health"]),
    }
    save_ticket(record)
    return {"ticket_id": ticket_id, **result}

@app.get("/analytics")
def analytics():
    return get_analytics()

@app.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: str):
    from .supportpilot.db import connect
    import json
    with connect() as conn:
        row = conn.execute("SELECT * FROM tickets WHERE ticket_id=?", (ticket_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Ticket not found")
    result = dict(row)
    result["tags"] = json.loads(result.pop("tags_json", "[]"))
    result["sources"] = json.loads(result.pop("sources_json", "[]"))
    result["escalated"] = bool(result["escalated"])
    return result

@app.post("/integrations/jira")
def jira_create(request: IntegrationTicketRequest):
    from .supportpilot.integrations import create_jira_issue
    try:
        return create_jira_issue(request.ticket_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Jira request failed: {exc}") from exc

@app.post("/integrations/email")
def email_send(request: EmailTicketRequest):
    from .supportpilot.integrations import send_ticket_email
    try:
        return send_ticket_email(request.ticket_id, request.recipient)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Email delivery failed: {exc}") from exc
