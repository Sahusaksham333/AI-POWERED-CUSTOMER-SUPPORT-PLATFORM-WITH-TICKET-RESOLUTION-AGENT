"""Small SQLite persistence layer for the local MVP."""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .config import DB_PATH


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                subject TEXT NOT NULL,
                body TEXT NOT NULL,
                language TEXT,
                queue TEXT,
                priority TEXT,
                ticket_type TEXT,
                tags_json TEXT NOT NULL DEFAULT '[]',
                status TEXT NOT NULL DEFAULT 'received',
                escalated INTEGER NOT NULL DEFAULT 0,
                response_draft TEXT,
                sources_json TEXT NOT NULL DEFAULT '[]',
                model_status TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON tickets(created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_queue ON tickets(queue)")


def save_ticket(ticket: dict[str, Any]) -> None:
    now = datetime.now(timezone.utc).isoformat()
    with connect() as conn:
        conn.execute("""
            INSERT INTO tickets (
                ticket_id, created_at, subject, body, language, queue, priority,
                ticket_type, tags_json, status, escalated, response_draft, sources_json, model_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(ticket_id) DO UPDATE SET
                queue=excluded.queue, priority=excluded.priority, ticket_type=excluded.ticket_type,
                tags_json=excluded.tags_json, status=excluded.status, escalated=excluded.escalated,
                response_draft=excluded.response_draft, sources_json=excluded.sources_json,
                model_status=excluded.model_status
        """, (
            ticket["ticket_id"], ticket.get("created_at", now), ticket.get("subject", ""),
            ticket.get("body", ""), ticket.get("language"), ticket.get("queue"),
            ticket.get("priority"), ticket.get("type"), json.dumps(ticket.get("tags", []), ensure_ascii=False),
            ticket.get("status", "received"), int(bool(ticket.get("escalated", False))),
            ticket.get("response_draft"), json.dumps(ticket.get("sources", []), ensure_ascii=False),
            ticket.get("model_status", "unknown"),
        ))


def get_analytics() -> dict[str, Any]:
    init_db()
    with connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]
        escalated = conn.execute("SELECT COUNT(*) FROM tickets WHERE escalated=1").fetchone()[0]
        statuses = [dict(r) for r in conn.execute("SELECT status, COUNT(*) AS count FROM tickets GROUP BY status")]
        queues = [dict(r) for r in conn.execute(
            "SELECT COALESCE(queue, 'unavailable') AS queue, COUNT(*) AS count FROM tickets GROUP BY queue ORDER BY count DESC"
        )]
        priorities = [dict(r) for r in conn.execute(
            "SELECT COALESCE(priority, 'unavailable') AS priority, COUNT(*) AS count FROM tickets GROUP BY priority ORDER BY count DESC"
        )]
        recent = [dict(r) for r in conn.execute(
            "SELECT ticket_id, created_at, subject, queue, priority, status, escalated FROM tickets ORDER BY created_at DESC LIMIT 25"
        )]
    return {"total_tickets": total, "escalated_tickets": escalated, "statuses": statuses,
            "queues": queues, "priorities": priorities, "recent_tickets": recent}
